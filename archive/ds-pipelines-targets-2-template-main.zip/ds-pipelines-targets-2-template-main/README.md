# ds-pipelines-targets-2-template
USGS targets tips and tricks: overview of conventions and best practices for using targets in USGS Data Science workflows
